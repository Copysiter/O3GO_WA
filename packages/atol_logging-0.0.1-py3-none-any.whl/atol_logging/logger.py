"""
Расширенный логгер AtolLogger с новыми уровнями,
JSON-форматированием и поддержкой Event.
"""
import logging
import traceback

from types import MappingProxyType
from typing import Dict, Final, Mapping, Optional

from .event import Event

# Новые уровни логирования
TRACE_LEVEL: Final[int] = 5
NOTICE_LEVEL: Final[int] = 25
FATAL_LEVEL: Final[int] = 60

_LEVEL_TO_SEVERITY: Final[Mapping[int, int]] = MappingProxyType({
    TRACE_LEVEL: 7,
    logging.DEBUG: 6,
    logging.INFO: 5,
    NOTICE_LEVEL: 4,
    logging.WARNING: 3,
    logging.ERROR: 2,
    logging.CRITICAL: 1,
    FATAL_LEVEL: 0,
})

logging.addLevelName(TRACE_LEVEL, 'TRACE')
logging.addLevelName(NOTICE_LEVEL, 'NOTICE')
logging.addLevelName(FATAL_LEVEL, 'FATAL')


class AtolLogger(logging.Logger):
    """
    Кастомный логгер с уровнями TRACE, NOTICE, FATAL и поддержкой Event.
    Выводит логи в JSON через JSONFormatter.
    """

    def trace(
        self,
        msg: Optional[str] = None,
        *args,
        **kwargs,
    ) -> None:
        """
        Метод логирование уровня TRACE (5).

        В kwargs поддерживаются ключи:
            event: Event или None
            event_code: str или None
        """
        self._log_ex(TRACE_LEVEL, msg, *args, **kwargs)

    def debug(  # type: ignore[override]
        self,
        msg: Optional[str] = None,
        *args,
        **kwargs,
    ) -> None:
        """
        Метод логирование уровня DEBUG (10).
        """
        self._log_ex(logging.DEBUG, msg, *args, **kwargs)

    def info(  # type: ignore[override]
        self,
        msg: Optional[str] = None,
        *args,
        **kwargs,
    ) -> None:
        """
        Метод логирование уровня INFO (20).
        """
        self._log_ex(logging.INFO, msg, *args, **kwargs)

    def notice(
        self,
        msg: Optional[str] = None,
        *args,
        **kwargs,
    ) -> None:
        """
        Метод логирование уровня NOTICE (25).
        """
        self._log_ex(NOTICE_LEVEL, msg, *args, **kwargs)

    def warning(  # type: ignore[override]
        self,
        msg: Optional[str] = None,
        *args,
        **kwargs,
    ) -> None:
        """
        Метод логирование уровня WARNING (30).
        """
        self._log_ex(logging.WARNING, msg, *args, **kwargs)

    def error(  # type: ignore[override]
        self,
        msg: Optional[str] = None,
        *args,
        **kwargs,
    ) -> None:
        """
        Метод логирование уровня ERROR (40).
        """
        self._log_ex(logging.ERROR, msg, *args, **kwargs)

    def exception(  # type: ignore[override]
        self,
        msg: Optional[str] = None,
        *args,
        **kwargs,
    ) -> None:
        """
        Метод логирование уровня ERROR (40) с выводом Traceback.
        """
        kwargs['exc_info'] = True
        self._log_ex(logging.ERROR, msg, *args, **kwargs)

    def critical(  # type: ignore[override]
        self,
        msg: Optional[str] = None,
        *args,
        **kwargs,
    ) -> None:
        """
        Метод логирование уровня CRITICAL (50).
        """
        self._log_ex(logging.CRITICAL, msg, *args, **kwargs)

    def fatal(  # type: ignore[override] # noqa: E501
        self,
        msg: Optional[str] = None,
        *args,
        **kwargs,
    ) -> None:
        """
        Метод логирование уровня FATAL (60).
        """
        self._log_ex(FATAL_LEVEL, msg, *args, **kwargs)

    def _log_ex(
        self,
        level: int,
        msg: Optional[str] = None,
        *args,
        **kwargs,
    ) -> None:
        """
        Вспомогательный метод для логирования с поддержкой Event и extra-полей.

        В kwargs поддерживаются:
            event: Event | None
            event_code: str | None
            extra: dict — дополнительные поля
        """
        # Извлекаем event и event_code из kwargs
        event: Optional[Event] = kwargs.pop('event', None)
        event_code: Optional[str] = kwargs.pop('event_code', None)
        exc_info = kwargs.pop('exc_info', None)

        if not event and event_code:
            event = Event.from_code(event_code)

        extra: Dict[str, object] = kwargs.pop('extra', {})
        if event:
            extra['event'] = event.to_dict()
        extra.setdefault('severity', _LEVEL_TO_SEVERITY.get(level, 5))

        # Добавление traceback в extra, если exc_info включено
        if exc_info:
            try:
                tb = traceback.format_exc()
                if tb.strip() != 'NoneType: None':
                    extra['traceback'] = tb
            except Exception:
                pass

        # Сообщение: при отсутствии msg используем message из event
        if msg is None and event:
            msg = event.message

        super()._log(level, msg, args, extra=extra)
