"""
Модуль formatter: JSONFormatter для структурированных JSON-логов.
"""
import json
import logging
import socket
from typing import Any, Dict, Optional


_RESERVED_KEYS = {
    'name', 'msg', 'args', 'levelname', 'levelno', 'pathname', 'filename',
    'module', 'exc_info', 'exc_text', 'stack_info', 'lineno', 'funcName',
    'created', 'msecs', 'relativeCreated', 'thread', 'threadName',
    'processName', 'process', 'timestamp', 'hostname', 'service',
    'message', 'signature_id', 'event_name', 'severity', 'event'
}


class JSONFormatter(logging.Formatter):
    """
    Форматер лог-записи в JSON для структурированного логирования.
    """

    def __init__(self, hostname: Optional[str] = None) -> None:
        """
        Инициализация JSONFormatter.

        Args:
            hostname: Переопределение имени хоста.
        """
        super().__init__()
        self.hostname = hostname or socket.gethostname()

    def format(self, record: logging.LogRecord) -> str:
        """
        Метод для преобразования LogRecord в JSON-строку.

        Включает стандартные поля: timestamp, service, name, level, message,
        event и user-defined extra-поля.
        """
        event = getattr(record, 'event', None)

        log_data: Dict[str, Any] = {
            'timestamp': self.formatTime(record, '%Y-%m-%dT%H:%M:%S.%fZ'),
            'service': getattr(record, 'service', {}),
            'name': record.name,
            'level': record.levelname,
            'message': record.getMessage(),
            'event': event,
            'extra': {}
        }

        for key, val in record.__dict__.items():
            if key not in _RESERVED_KEYS and not key.startswith('_'):
                log_data['extra'][key] = val

        return json.dumps(log_data, ensure_ascii=False, separators=(',', ':'))
