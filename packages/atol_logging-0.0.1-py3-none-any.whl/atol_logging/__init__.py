"""
Пакет atol_logging — модуль JSON логирования с поддержкой дерева событий.

Содержит:
- AtolLogger — расширенный логгер с дополнительными уровнями
- JSONFormatter — форматер для вывода логов в JSON формате
- Event — объектная модель дерева событий
- Config — тип для определения структуры дерева событий
- UnknownEventFilter — фильтр для присвоения дефолтного события
- RequestIdFilter — фильтр для логирования сквозного ID запроса
"""
import os
import sys
import socket
import logging
from logging.handlers import RotatingFileHandler, TimedRotatingFileHandler
from typing import Any, Optional, Literal, Dict, cast

from .logger import AtolLogger                              # noqa: F401
from .event import Config, Event                            # noqa: F401
from .formatter import JSONFormatter                        # noqa: F401
from .filters import UnknownEventFilter, RequestIdFilter    # noqa: F401


__all__ = [
    'AtolLogger', 'JSONFormatter', 'Config', 'Event',
    'UnknownEventFilter', 'RequestIdFilter', 'setup_logger'
]


def setup_logger(  # noqa: E501
    name: str,
    level: int | str = logging.INFO,
    stdout: bool = True,
    log_path: Optional[str] = None,
    rotation_type: Optional[Literal["size", "time"]] = None,
    rotation_max_bytes: int = 10 * 1024 * 1024,
    rotation_when: str = "midnight",
    rotation_interval: int = 1,
    backup_count: int = 7,
    enabled_loggers: Optional[Dict[str, str | int]] = None,
    service: Optional[Dict[str, str]] = None,
) -> AtolLogger:
    """
    Создание глобального экземпляра AtolLogger с заданными параметрами.
    Регистрация и конфигурация логгеров сторонних библиотек

    Args:
        name: Название экземпляра AtolLogger.
        level: Уровень логирования (число или строка).
        stdout: Вывод логов в stdout.
        log_path: Путь к файлу лога (если None — вывод только в stdout).
        rotation_type: Тип ротации: 'size', 'time' или None.
        rotation_max_bytes: Максимальный размер для ротации по размеру.
        rotation_when: Интервал для временной ротации.
        rotation_interval: Частота для временной ротации.
        backup_count: Количество сохраняемых резервных файлов.
        enabled_loggers: Словарь имен и уровней сторонних логгеров.
        service: Информация о сервисе (name, version, и т.д.).

    Returns:
        Настроенный экземпляр AtolLogger.
    """
    # Обогащаем словарь service именем хоста
    service = service or {}
    service.update(host=socket.gethostname())

    # Создаём кастомную фабрику лог-записей для добавления service
    old_factory = logging.getLogRecordFactory()

    def record_factory(*args: Any, **kwargs: Any) -> logging.LogRecord:
        record = old_factory(*args, **kwargs)
        record.service = service
        return record

    logging.setLogRecordFactory(record_factory)

    # Устанавливаем кастомный класс логгера
    logging.setLoggerClass(AtolLogger)

    # Получаем логгер по имени и задаём уровень
    logger: AtolLogger = cast(AtolLogger, logging.getLogger(name))
    logger.setLevel(level)

    # Гарантируем наличие словаря активных логгеров
    if enabled_loggers is None:
        enabled_loggers = {}
    enabled_loggers[name] = level

    # Создаём JSON-форматтер
    formatter = JSONFormatter()

    # Фабрика для создания файлового хэндлера с учётом ротации
    def create_file_handler(
        path: str,
        rotation: Optional[str],
        max_bytes: int,
        when: str,
        interval: int,
        backups: int,
    ) -> logging.Handler:
        # Создаём директорию, если указана
        dir_name = os.path.dirname(path)
        if dir_name:
            os.makedirs(dir_name, exist_ok=True)

        # Возвращаем хэндлер соответствующего типа
        if rotation == "size":
            return RotatingFileHandler(
                path, maxBytes=max_bytes, backupCount=backups
            )
        if rotation == "time":
            return TimedRotatingFileHandler(
                path, when=when, interval=interval, backupCount=backups
            )
        return logging.FileHandler(path, encoding="utf-8")

    # Инициализируем логгеры из enabled_loggers (если ещё не созданы)
    for log_name in enabled_loggers:
        logging.getLogger(log_name)

    # Получаем все зарегистрированные логгеры через внутренний API logging.
    logger_dict = logging.Logger.manager.loggerDict
    for log_name, log_obj in logger_dict.items():
        if isinstance(log_obj, logging.PlaceHolder):
            continue  # Пропускаем "заглушки"

        # Получаем уровень логирования
        log_level = enabled_loggers.get(log_name, level)
        if isinstance(log_level, str):
            log_level = getattr(logging, log_level.upper(), level)

        # Очищаем хэндлеры перед повторной настройкой
        log_obj.handlers.clear()

        if log_name in enabled_loggers:
            # Активируем логгер
            log_obj.disabled = False
            log_obj.setLevel(log_level)
            log_obj.addFilter(UnknownEventFilter())

            file_handler = None
            if log_path:
                file_handler = create_file_handler(
                    path=log_path,
                    rotation=rotation_type,
                    max_bytes=rotation_max_bytes,
                    when=rotation_when,
                    interval=rotation_interval,
                    backups=backup_count,
                )

            # Создаём stdout хэндлер (если включён)
            if stdout:
                console_handler = logging.StreamHandler(sys.stdout)
                console_handler.setFormatter(formatter)
                console_handler.setLevel(log_level)
                log_obj.addHandler(console_handler)

            # Добавляем файловый хэндлер (если есть)
            if file_handler:
                file_handler.setFormatter(formatter)
                file_handler.setLevel(log_level)
                log_obj.addHandler(file_handler)
        else:
            # Отключаем логгер, если он не в списке разрешённых
            log_obj.disabled = True

    return logger
