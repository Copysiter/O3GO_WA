"""
Хранение контекста запросов (request_id) через contextvars.
"""
import contextvars

request_id: contextvars.ContextVar[str | None] = \
    contextvars.ContextVar('request_id', default=None)
