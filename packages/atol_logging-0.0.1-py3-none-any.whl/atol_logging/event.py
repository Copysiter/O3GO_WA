"""
Объектная модель дерева событий для структурированного логирования.
"""
from typing import Dict, Tuple, Union, Optional

# Типы конфигурации
Segment = Union[str, int]
Message = str
Leaf = Union[Segment, Tuple[Segment, Message]]
Branch = Tuple[Segment, 'Config']
Config = Dict[str, Union[Leaf, Branch]]


class Event:
    """
    Универсальный узел дерева событий.

    Leaf:
        code: строка вида AABBCC
        name: строка вида SUB1.SUB2.SUB3
        message: дефолтное описание события

    Branch:
        Интерфейс для доступ к вложенным событиям через атрибуты.
    """
    _nodes: Dict[str, 'Event'] = {}

    def __init__(
        self,
        data: Union[Config, Branch, Leaf],
        _prefix: str = '',
        _path: Tuple[str, ...] = (),
    ) -> None:
        self._prefix = _prefix
        self._path = _path
        # Ветка — словарь
        if isinstance(data, dict):
            for name, value in data.items():
                setattr(
                    self,
                    name,
                    Event(value, _prefix, _path + (name,))
                )
        # Ветка — кортеж с детьми
        elif isinstance(data, tuple) and isinstance(data[1], dict):
            segment, children = data  # type: ignore[index]
            prefix = _prefix + str(segment).zfill(2)
            self._prefix = prefix
            for name, value in children.items():
                setattr(
                    self,
                    name,
                    Event(value, prefix, _path + (name,))
                )
        else:
            # Лист — кортеж с кодом и сообщением
            if isinstance(data, tuple) and isinstance(data[1], str):
                segment, msg = data
                self.message = msg
            # Лист — сегмент кода
            else:
                segment = data  # type: ignore[assignment]
                self.message = ''

            self.code = _prefix + str(segment).zfill(2)
            self.name = '.'.join(_path)
            Event._nodes[self.code] = self

    def __getattr__(self, item: str) -> 'Event':
        if item == "EV0":
            # Сегмент 00 — добавляем к текущему префиксу
            segment = '00'
            code = getattr(self, '_prefix', '') + segment
            name = '.'.join(getattr(self, '_path', ())) + '.EV0'
            message = 'Дефолтное событие'

            # Возвращаем объект Event
            temp = Event.__new__(Event)
            temp.code = code.ljust(6, '0')
            temp.name = name
            temp.message = message
            return temp

        raise AttributeError(
            f"{self.__class__.__name__!r} object has no attribute {item!r}")

    @classmethod
    def from_code(cls, code: Union[str, int]) -> Optional['Event']:
        """
        Метод для Получения объекта Event по его коду.

        Args:
            code: код события в формате AABBCC.

        Returns:
            Экземпляр Event или None, если код не найден.
        """
        return cls._nodes.get(str(code))

    def to_dict(self) -> Dict[str, Union[str, Dict]]:
        """
        Метод для рекурсивного конвертирования дерева Event в словарь.

        Leaf: {'code': ..., 'name': ..., 'message': ...}
        Branch: {'SUB1': {...}, 'SUB2': {...}}
        """
        if hasattr(self, 'code'):
            return {
                'code': self.code,
                'name': self.name,
                'message': self.message,
            }
        return {
            key: val.to_dict()
            for key, val in self.__dict__.items()
            if isinstance(val, Event)
        }

    def __repr__(self) -> str:
        if hasattr(self, 'code'):
            return (
                f'Event(code="{self.code}", name="{self.name}", '
                f'message="{self.message}")'
            )
        return f'<Event namespace: {list(self.__dict__.keys())}>'
