"""
Фильтры UnknownEventFilter и RequestIdFilter для логирования.
"""
from logging import Filter, LogRecord

from .context import request_id as ctx_request_id


class UnknownEventFilter(Filter):
    """
    Фильтр, назначающий дефолтное событие для сторонних логгеров без event.
    """

    def filter(self, record: LogRecord) -> bool:
        if not getattr(record, 'event', None):
            record.event = {'code': '000000', 'name': 'UNKNOWN', 'message': ''}
        return True


class RequestIdFilter(Filter):
    """
    Фильтр, добавляющий в логи сквозной request_id из contextvar.
    """

    def filter(self, record: LogRecord) -> bool:
        record.request_id = ctx_request_id.get()
        return True
